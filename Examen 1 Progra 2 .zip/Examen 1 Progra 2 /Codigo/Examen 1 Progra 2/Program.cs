﻿
//modelar cuales son las entidades CLASES que se puede tomar de cada uno de
//enunciados y determinar los atributos de cada clase
//despues hay que disenar las tablas que ayudarian a guardar la informacion en la base de datos
// despues crear una plantilla en HTML Simulando que se capturan los datos del enunciado que escogi
// Diagrama de flujo o pseudocodigo para resolver el enunciado
// Programa en C# Para resolver el sistema

//SQL
//DOCUMENTACION
//PAGINA WEB
//PROGRAMA

using System;
using System.Collections.Generic;

namespace MyApp
{
    internal class Program
    {
        static List<Usuario> usuarios = new List<Usuario>();
        static List<MaterialReciclable> materialesReciclados = new List<MaterialReciclable>();
        static Dictionary<string, int> recompensas = new Dictionary<string, int>();

        static void Main(string[] args)
        {
            Console.WriteLine("Esto es un Programa de Recompensas por reciclar, Bienvenido");
            Console.WriteLine("A continuación, tiene un menú de opciones, seleccione una opción");
            Menu();
        }

        public static void Menu()
        {
            while (true)
            {
                Console.WriteLine("Digite 1 para comenzar a reciclar");
                Console.WriteLine("Digite 2 para ver las estadísticas");
                Console.WriteLine("Digite 3 para ver las recompensas");
                Console.WriteLine("Digite 4 para salir del programa");

                int opcion;
                if (int.TryParse(Console.ReadLine(), out opcion))
                {
                    switch (opcion)
                    {
                        case 1:
                            // Lógica para comenzar a reciclar
                            Console.WriteLine("Comenzando a reciclar...");
                            CapturarDatosUsuario();
                            CapturarReciclaje();
                            ActualizarPuntos(); 
                            break;
                        case 2:
                            // Lógica para ver las estadísticas
                            Console.WriteLine("Mostrando estadísticas...");
                            MostrarEstadisticas();
                            break;
                        case 3:
                            // Lógica para ver las recompensas
                            Console.WriteLine("Mostrando recompensas...");
                            CargarRecompensas();
                            MostrarRecompensas();
                            Console.WriteLine("Desea comprar alguna recompensa?");
                            string respuesta = Console.ReadLine();
                            while (respuesta.ToLower() =="si")
                            {
                                ComprarRecompensa();
                                Console.WriteLine("Desea comprar algo mas?");
                                respuesta = Console.ReadLine();
                            }
                            break;
                        case 4:
                            // Salir del programa
                            Console.WriteLine("Saliendo del programa...");
                            return;
                        default:
                            Console.WriteLine("Opción no válida, por favor intente de nuevo.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Entrada no válida. Por favor, ingrese un número.");
                }
            }
        }

        public static void CapturarDatosUsuario()
        {
            Console.WriteLine("Por favor ingrese los datos del usuario");
            Console.Write("Cédula: ");
            int cedula;
            while (!int.TryParse(Console.ReadLine(), out cedula))
            {
                Console.WriteLine("Cédula inválida. Por favor, ingrese un número válido.");
                Console.Write("Cédula: ");
            }
            Console.Write("Nombre: ");
            string nombre = Console.ReadLine();

            Usuario nuevoUsuario = new Usuario
            {
                Cedula = cedula,
                Nombre = nombre,
                PuntosAcumulados = 0
            };

            usuarios.Add(nuevoUsuario);

            Console.WriteLine("Usuario registrado correctamente.");
        }

        public static void CapturarReciclaje()
        {
            Console.WriteLine("Ahora ingrese los materiales a reciclar, 1 tipo a la vez");

            string respuesta;
            do
            {
                // Mostrar los tipos de materiales reciclables disponibles
                Console.WriteLine("Tipos de materiales reciclables:");
                Console.WriteLine("1. Papel y cartón");
                Console.WriteLine("2. Plástico");
                Console.WriteLine("3. Vidrio");
                Console.WriteLine("4. Metal");
                Console.WriteLine("5. Orgánicos");

                int tipoSeleccionado;
                while (true)
                {
                    Console.Write("Seleccione el tipo de material (1-5): ");
                    if (int.TryParse(Console.ReadLine(), out tipoSeleccionado) && tipoSeleccionado >= 1 && tipoSeleccionado <= 5)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Selección no válida. Por favor, ingrese un número entre 1 y 5.");
                    }
                }

                //asignar puntos por material
                string tipoDeMaterial = "";
                int puntosPorMaterial = 0;
                switch (tipoSeleccionado)
                {
                    case 1:
                        tipoDeMaterial = "Papel y cartón";
                        puntosPorMaterial = 1;
                        break;
                    case 2:
                        tipoDeMaterial = "Plástico";
                        puntosPorMaterial = 2;
                        break;
                    case 3:
                        tipoDeMaterial = "Vidrio";
                        puntosPorMaterial = 3;
                        break;
                    case 4:
                        tipoDeMaterial = "Metal";
                        puntosPorMaterial = 4;
                        break;
                    case 5:
                        tipoDeMaterial = "Orgánicos";
                        puntosPorMaterial = 5;
                        break;
                }

                Console.Write("Descripción: ");
                string descripcion = Console.ReadLine();

                int cantidad;
                while (true)
                {
                    Console.Write("Cantidad en unidades: ");
                    if (int.TryParse(Console.ReadLine(), out cantidad))
                    {
                        if (cantidad <= 0)
                        {
                            Console.WriteLine("La cantidad debe ser un número positivo. Intente de nuevo.");
                        }
                        else
                        {
                            int puntosAcumulados = (cantidad / 5) * puntosPorMaterial;

                            // Crear una instancia de MaterialReciclable con los datos capturados
                            MaterialReciclable materialReciclable = new MaterialReciclable
                            {
                                TipoDeMaterial = tipoDeMaterial,
                                Descripcion = descripcion,
                                PuntosPorMaterial = puntosPorMaterial,
                                CantidadUnidades = cantidad,
                                PuntosAcumulados = puntosAcumulados,
                                Cedula = usuarios[usuarios.Count - 1].Cedula // Asignar la cédula del último usuario registrado
                            };

                            materialesReciclados.Add(materialReciclable);

                            Console.WriteLine("Material reciclado registrado:");
                            Console.WriteLine($"Tipo de material: {materialReciclable.TipoDeMaterial}");
                            Console.WriteLine($"Descripción: {materialReciclable.Descripcion}");
                            Console.WriteLine($"Cantidad: {materialReciclable.CantidadUnidades}");
                            Console.WriteLine($"Puntos acumulados: {materialReciclable.PuntosAcumulados}");

                            break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Entrada no válida. Por favor, ingrese un número válido.");
                    }
                }

                Console.Write("Desea ingresar otro tipo de material para reciclar? (si/no): ");
                respuesta = Console.ReadLine().ToLower();
            } while (respuesta == "si");
        }
        public static void ActualizarPuntos()
        {
            foreach (var usuario in usuarios)
            {
                int puntosUsuario = 0;
                foreach (var material in materialesReciclados)
                {
                    if (material.Cedula == usuario.Cedula)
                    {
                        puntosUsuario += material.PuntosAcumulados;
                    }
                }
                usuario.PuntosAcumulados = puntosUsuario;
            }
        }

        public static void MostrarEstadisticas()
        {
            Console.WriteLine("Participantes:");
            foreach (var usuario in usuarios)
            {
                Console.WriteLine($"Cédula: {usuario.Cedula}, Nombre: {usuario.Nombre}");
                Console.WriteLine($"Artículos reciclados:");
                int totalPuntosUsuario = 0;
                foreach (var material in materialesReciclados)
                {
                    if (material.Cedula == usuario.Cedula)
                    {
                        Console.WriteLine($"  {material.TipoDeMaterial}: {material.CantidadUnidades}");
                        totalPuntosUsuario += material.PuntosAcumulados;
                    }
                }
                Console.WriteLine($"Total puntos acumulados: {totalPuntosUsuario}");
            }

            Dictionary<string, int> totalPorTipo = new Dictionary<string, int>();
            foreach (var material in materialesReciclados)
            {
                if (totalPorTipo.ContainsKey(material.TipoDeMaterial))
                {
                    totalPorTipo[material.TipoDeMaterial] += material.CantidadUnidades;
                }
                else
                {
                    totalPorTipo[material.TipoDeMaterial] = material.CantidadUnidades;
                }
            }

            Console.WriteLine("\nTotal de artículos reciclados por tipo de material:");
            foreach (var tipo in totalPorTipo)
            {
                Console.WriteLine($"  {tipo.Key}: {tipo.Value}");
            }
        }

        public static void CargarRecompensas()
        {
            recompensas.Add("Camiseta", 30);
            recompensas.Add("Taza", 5);
            recompensas.Add("Libro", 30);
            recompensas.Add("Estuche", 20);
            recompensas.Add("Bola", 15);

        }

        public static void MostrarRecompensas()
        {
            Console.WriteLine("Recompensas disponibles:");
            foreach (var recompensa in recompensas)
            {
                Console.WriteLine($"  {recompensa.Key}: {recompensa.Value} puntos");
            }
        }
        public static void ComprarRecompensa()
        {
            Console.WriteLine("Ingrese la cédula del usuario que desea comprar la recompensa:");
            int cedula;
            while (!int.TryParse(Console.ReadLine(), out cedula))
            {
                Console.WriteLine("Cédula inválida. Por favor, ingrese un número válido:");
            }

            Usuario usuario = BuscarUsuarioPorCedula(cedula);
            if (usuario != null)
            {
                Console.WriteLine($"Usuario encontrado: {usuario.Nombre}");

                Console.WriteLine("Recompensas disponibles:");
                foreach (var recompensa in recompensas)
                {
                    Console.WriteLine($"  {recompensa.Key}: {recompensa.Value} puntos");
                }

                Console.WriteLine("Ingrese el nombre de la recompensa que desea comprar:");
                string nombreRecompensa = Console.ReadLine();

                if (recompensas.ContainsKey(nombreRecompensa))
                {
                    int puntosNecesarios = recompensas[nombreRecompensa];
                    if (usuario.PuntosAcumulados >= puntosNecesarios)
                    {
                        usuario.PuntosAcumulados -= puntosNecesarios;
                        Console.WriteLine($"¡Felicidades, {usuario.Nombre}! Has comprado la recompensa: {nombreRecompensa}");
                        Console.WriteLine($"Puntos Disponibles despues de la compra {usuario.PuntosAcumulados}");
                        
                    }
                    else
                    {
                        Console.WriteLine($"Lo siento, {usuario.Nombre}, no tienes suficientes puntos para comprar esta recompensa.");
                    }
                }
                else
                {
                    Console.WriteLine("Recompensa no encontrada.");
                }
            }
            else
            {
                Console.WriteLine("Usuario no encontrado.");
            }
        }

        public static Usuario BuscarUsuarioPorCedula(int cedula)
        {
            foreach (var usuario in usuarios)
            {
                if (usuario.Cedula == cedula)
                {
                    return usuario;
                }
            }
            return null;
        }

        public class Usuario
        {
            public int Cedula { get; set; }
            public string Nombre { get; set; }
            public int PuntosAcumulados { get; set; }
        }

        public class MaterialReciclable
        {
            public string TipoDeMaterial { get; set; }
            public string Descripcion { get; set; }
            public int PuntosPorMaterial { get; set; }
            public int CantidadUnidades { get; set; }
            public int PuntosAcumulados { get; set; }
            public int Cedula { get; set; }
        }

        public class Recompensas
        {
            public string Articulo { get; set; }
            public int PuntosNecesarios { get; set; }
        }
    }
}
