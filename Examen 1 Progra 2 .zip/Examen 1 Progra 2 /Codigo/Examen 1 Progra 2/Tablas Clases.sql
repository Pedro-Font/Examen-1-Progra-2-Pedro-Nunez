CREATE TABLE Usuario (
    Cedula INT PRIMARY KEY,
    Nombre NVARCHAR(100), 
    PuntosAcumulados INT
);

CREATE TABLE MaterialReciclable (
    TipoDeMaterial VARCHAR(50),
    Descripcion VARCHAR(255),
    PuntosPorMaterial INT,
    CantidadUnidades INT,
    PuntosAcumulados INT,
    Cedula INT,
    FOREIGN KEY (Cedula) REFERENCES Usuario(Cedula) -- Establece la relación con la tabla Usuario
);


CREATE TABLE Recompensas (
    Articulo VARCHAR(100) PRIMARY KEY,	
    PuntosNecesarios INT
);